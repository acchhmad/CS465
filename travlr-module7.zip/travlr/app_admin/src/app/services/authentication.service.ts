import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { TripDataService } from './trip-data.service';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private readonly tokenKey = 'travlr-token';

  constructor(private tripDataService: TripDataService) { }

  public getToken(): string {
    return localStorage.getItem(this.tokenKey) || '';
  }

  public saveToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
  }

  public logout(): void {
    localStorage.removeItem(this.tokenKey);
  }

  public isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  }

  public getCurrentUser(): User | null {
    if (!this.isLoggedIn()) {
      return null;
    }
    const token = this.getToken();
    const { email, name } = JSON.parse(atob(token.split('.')[1]));
    return { email, name };
  }

  public login(user: User, password: string): Observable<AuthResponse> {
    return this.tripDataService.login(user, password).pipe(
      tap((authResponse: AuthResponse) => this.saveToken(authResponse.token))
    );
  }

  public register(user: User, password: string): Observable<AuthResponse> {
    return this.tripDataService.register(user, password).pipe(
      tap((authResponse: AuthResponse) => this.saveToken(authResponse.token))
    );
  }
}
